define(["jquery", "jquery.bootpag"], function($, bootpag) {
    $.fn.bootpag = bootpag;
    return bootpag;
});